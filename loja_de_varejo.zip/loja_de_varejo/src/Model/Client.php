<?php

namespace APP\Model;

class Client
{
    private string $cpf;
    private string $name;
    private Address $address;
}
<?php

namespace APP\Model;
class Address{
    private string $publicPlace;
    private int $streetNumber;
    private string $neighborhood;
    private string $city;
    private string $postalCode;

    public function __construct(
        string $publicPlace,
        string $streetNumber,
        string $postalCode,
        string $neighborhood,
        string $city,
    )
    {
        $this->publicPlace = $publicPlace;
        $this->streetNumber = $streetNumber;
        $this->postalCode = $postalCode;
        $this->neighborhood = $neighborhood;
        $this->city = $city;
    }
}


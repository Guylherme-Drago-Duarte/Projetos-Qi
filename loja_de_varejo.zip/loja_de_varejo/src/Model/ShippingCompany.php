<?php

namespace APP\Model;

class ShippingCompany
{
    private string $cnpj;
    private string $name;
    private Address $address;
    
}
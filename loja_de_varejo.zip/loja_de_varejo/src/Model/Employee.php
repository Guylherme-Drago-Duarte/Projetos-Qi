<?php

namespace APP\Model;

class Employee
{
    private int $register;
    private string $name;
    private float $salary;
    private Address $address;
    
}
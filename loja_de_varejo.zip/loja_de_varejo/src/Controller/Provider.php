<?php

namespace APP\Controller;

use APP\Model\Product;
use APP\Model\Provider;
use APP\Utils\Redirect;
use APP\Model\Validation;

require '../../vendor/autoload.php';

if (empty($_POST)) {
    session_start();
    Redirect::redirect(
        type: 'error',
        message: 'Requisição inválida!'
    );
}

$cnpj = $_POST ["cnpj"];
$name = $_POST ["name"];
$phone = $_POST ["phone"];

$error = array();
if(!Validation::validateName($name)){
    array_push($error, "O nome deve conter acima de 2 caracteres");
}
if(!Validation::validatePhone($phone)){
    array_push($error, "O numero deve ser maior que zero ");
}
if($error){
    Redirect::redirect(
        message: $error,
        type: 'warning'
    );
}
else{
    Redirect::redirect(
        message: "O fornecedor $name foi cadastrado!"
    );
}
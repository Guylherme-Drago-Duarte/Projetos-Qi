<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Loja de varejo - Cadastro de Fornecedor</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <form action="../Controller/Provider.php" method="POST">
        <fieldset class="p-4 m-5 border border-blue-400">
            <legend>Cadastro do Fornecedor</legend>
            <section class="columns-2">
                <article>
                    <label for="name">Nome do Fornecedor</label>
                    <input type="text" id="name" name="name" class="border border-blue-400" required minlength="5">
                </article>
                <article>
                    <label for="phone">Telefone</label>
                    <input type="text" id="phone" name="phone" class="border border-blue-400" required min="1" max="1000">
                </article>
            </section>
            <section class="mt-4 columns-2">
                <article>
                    <label for="cnpj">CNPJ</label>
                    <input type="text" id="cnpj" name="cnpj" class="border border-blue-400" required maxlength="14" minlength="14">
                </article>
            </section>
        </fieldset>
        <fieldset class="p-4 m-5 border border-blue-400">
            <legend> Cadastro de Endereço</legend>
                <section class="columns-2">
                    <article class="justify-between p-4">
                        <label for="publicPlace"> Logradouro</label>
                        <input type="text" id="publicPlace" name="publicPlace" class="border border-blue-400"required minlength="5">
                    </article>
                    <article class="justify-between p-4">
                        <label for="streetNumber">Número da rua</label>
                        <input type="text" id="streetNumber" name="streetNumber" class="border border-blue-400" required min="1" max="1000" >
                    </article>
                    <article class="justify-between p-4">
                        <label for="neighborhood">Bairro</label>
                        <input type="text" id="neighborhood" name="neighborhood" class="border border-blue-400" required minlength="5">
                    </article>
                    <article class="justify-between p-4">
                        <label for="city">Cidade</label>
                        <input type="text" id="city" name="city" class="border border-blue-400" required minlength="5">
                    </article>
                    <article class="justify-between p-4">
                        <label for="postalCode">CEP</label>
                        <input type="text" id="postalCode" name="postalCode" class="border border-blue-400" required minlength="5">
                    </article>
                </section>
        </fieldset>
        <article class="flex justify-center mt-4">
            <button type="submit" class="p-4 text-white bg-blue-800 rounded">Cadastrar</button>
        </article>
    </form>
</body>

</html>